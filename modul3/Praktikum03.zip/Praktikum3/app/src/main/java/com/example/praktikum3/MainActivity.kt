package com.example.praktikum3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.view.isVisible
import com.example.praktikum3.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.hasil.isVisible = false
        binding.convertButton.setOnClickListener{moneyconvert()}
    }

    private fun moneyconvert() {
        val total = binding.inputUang.text.toString()
        val banyakuang = total.toDoubleOrNull()

        if(banyakuang == null) {
            binding.hasil.text = " "
            return
        }
        val konversi = when (binding.pilihanCurrency.checkedRadioButtonId){
            R.id.euro_currency -> 16000.0
            R.id.USD_currency -> 14000.0
            R.id.yen_currency ->  114.0
            else -> 4000.0
        }
        var hasilkonversi = banyakuang*konversi
        displayKonversi(hasilkonversi)
    }

    private fun displayKonversi(uang : Double) {
        val indonesianLocale = Locale("in", "ID")
        val formattedrupiah = NumberFormat.getCurrencyInstance(indonesianLocale).format(uang)
        binding.hasil.text = getString(R.string.Hasil ,formattedrupiah)
        binding.hasil.isVisible = true
    }
}